from flask import *
from database import *
import uuid

artist=Blueprint("artist",__name__)



@artist.route('/artisthome')
def artisthome():

    return render_template("artisthome.html")

@artist.route('/viewuser_artist')
def viewuser():
    data={}
    qry="select * from user"
    res=select(qry)
    if res:
        data['view']=res
    return render_template("viewuser_artist.html",data=data)

@artist.route('/viewrating')
def viewrating():
    data={}
    qry="select * from rating where artistid='%s'"%(session['artist']) 
    res=select(qry)
    if res:
        data['view']=res
    return render_template("viewrating.html",data=data)

@artist.route('/viewpayment')
def viewpayment():
    data={}
    qry="select * from payment"
    res=select(qry)
    if res:
        data['view']=res
    return render_template("viewpayment.html",data=data)

@artist.route('/viewguidance')
def viewguidance():
    data={}
    random = None
    
    qry="select * from request where artistid='%s'"%(session['artist'])
    res=select(qry)
    if res:
        data['view']=res

    if 'action' in request.args:
        action=request.args['action']
        id=request.args['id']

    else:
        action=None

    if action=='accept':
        qry1="update request set status='Accepted' where requestid='%s'"%(id)
        update(qry1)
        res1=update(qry1)
        if res1:
            random="something"
        
        return f"<script>alert('success');window.location='/artist_assign_amt?r_id={id}'</script>" 

    if action=='reject':
        qry2="update request set status='Rejected' where requestid='%s'"%(id) 
        update(qry2)
        return "<script>alert('success');window.location='/viewguidance'</script>" 
    
    if 'accept' in request.form:

        amount=request.form['amount']       

        qry2="update request set amount='%s' where requestid='%s'"%(amount,id)
        update(qry2)
        return "<script>alert('success');window.location='/viewquidance'</script>"
    
    print(random,"++++++++++=")
    return render_template("viewguidance.html",data=data)


@artist.route('/artist_assign_amt',methods=['POST','GET'])
def artist_assign_amt():
    request_id=request.args['r_id']
    if 'update' in request.form:
        amount=request.form['amount']
        
        qry1="update request set amount='%s' where requestid='%s'"%(amount,request_id)
        update(qry1)
        return "<script>alert('success');window.location='/viewguidance'</script>"

    return render_template("artist_assign_amt.html")

@artist.route('/vieworders')
def vieworders():
    data={}
    qry="select * from booking_child"
    res=select(qry)
    if res:
        data['view']=res
    return render_template("vieworders.html",data=data)




@artist.route('/manage_work',methods=['POST','GET'])
def manage_work():
    if 'submit' in request.form:
        work_name=request.form['work_name']
        file=request.files['path']
        path=r'static/work/'+work_name+".jpg"
        file.save(path)
        amount=request.form['amount']


        qry="insert into works values(null,'%s','%s','%s','%s','pending')"%(session['artist'],work_name,path,amount)
        insert(qry)
        return "<script>alert('success');window.location='/manage_work'</script>"
  


    data={}
    qry="select * from works where artistid='%s'"%(session['artist'])
    res=select(qry)
    if res:
        data['view']=res



    if 'action' in request.args:
        action=request.args['action']
        id=request.args['id']
    else:
        action=None

    if action=='update':
        qry1="select * from works where workid='%s'"%(id)
        res1=select(qry1)
        if res1:
            data['up']=res1


    if action=='delete':
        qry3="delete from works where workid='%s' "%(id)     
        delete(qry3)
        return "<script>alert('success');window.location='/manage_work'</script>"   

    if 'update' in request.form:
        work_name=request.form['work_name']
        path=request.form['path']
        amount=request.form['amount']       

        qry2="update works set workname='%s',path='%s',amount='%s' where workid='%s'"%(work_name,path,amount,id)
        update(qry2)
        return "<script>alert('success');window.location='/manage_work'</script>" 


    return render_template("manageworks.html",data=data)



@artist.route('/manage_tutorial',methods=['POST','GET'])
def manage_tutorial():
    if 'submit' in request.form:
        title=request.form['title']
        file=request.files['path']
        path="static/"+str(uuid.uuid4())+file.filename
        file.save(path)
        date=request.form['date']


        qry="insert into tutorials values(null,'%s','%s','%s','%s')"%(session['artist'],title,path,date)
        insert(qry)
        return "<script>alert('success');window.location='/manage_tutorial'</script>"

    data={}
    qry="select * from tutorials where artistid='%s'"%(session['artist'])
    res=select(qry)
    if res:
        data['view']=res



    if 'action' in request.args:
        action=request.args['action']
        id=request.args['id']
    else:
        action=None

    if action=='update':
        qry1="select * from tutorials where tutorialid='%s'"%(id)
        res1=select(qry1)
        if res1:
            data['up']=res1


    if action=='delete':
        qry3="delete from tutorials where tutorialid='%s' "%(id)     
        delete(qry3)  
        return "<script>alert('success');window.location='/manage_tutorial'</script>"
 

    if 'update' in request.form:
        title=request.form['title']
        path=request.form['path']
        date=request.form['date']       

        qry2="update tutorials set title='%s',path='%s',date='%s' where tutorialid='%s'"%(title,path,date,id)
        update(qry2)
        return "<script>alert('success');window.location='/manage_tutorial'</script>"




    return render_template("managetutorials.html",data=data)